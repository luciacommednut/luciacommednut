---
title: La Primera Cosa Cat
image: images/pic01.jpg
date: "2020-01-01T00:00:00"
tags:
  - exemple
  - lorem ipsum catala
---
No hi ha ningú com ell, facilitat per fer coses i ser millor que ell és difícil. Que penses ? 
<!-- more -->
El laoreet de l'etiqueta està suspès al mètode del justificador just.